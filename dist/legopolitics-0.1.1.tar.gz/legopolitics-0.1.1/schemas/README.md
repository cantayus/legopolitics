# Schemas

Machine-readable JSON schemas can be generated with `legopolitics schema`. Typed source schemas live in `src/legopolitics/schemas`.
