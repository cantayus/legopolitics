# Security

Report vulnerabilities privately. Never include tokens, credentials, or restricted data in reports.
